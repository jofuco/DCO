package com.seatseller.core.lugares;

public class CatalogoReservas {

}
