package com.seatseller.core.utilizadores;

public class ClienteFinal extends Utilizador {

	public ClienteFinal(String u, String p) {
		super(u, p);
	}
}
