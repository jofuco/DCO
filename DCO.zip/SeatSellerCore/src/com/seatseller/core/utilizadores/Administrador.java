package com.seatseller.core.utilizadores;

public class Administrador extends Utilizador {

	public Administrador(String u, String p) {
		super(u, p);
	}

}
