package com.seatseller.core.utilizadores;

public enum TipoDeUtilizador {
	ADMIN,
	FUNCIONARIO,
	CLIENTE_FINAL
}
