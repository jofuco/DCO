package com.seatseller.handlers;

import com.seatseller.api.IDesassociarGrelhaHandler;
import com.seatseller.api.INotificacaoReceiver;

public class DesassociarGrelhaHandler implements IDesassociarGrelhaHandler {
	
	@Override
	public void desassociarGrelha(String desig, INotificacaoReceiver c) {
		// TODO
	}
}
