package com.seatseller.handlers;

import com.seatseller.api.IAssociarGrelhaHandler;
import com.seatseller.api.INotificacaoReceiver;

public class AssociarGrelhaHandler implements IAssociarGrelhaHandler {

	@Override
	public void associarGrelha(String desig, INotificacaoReceiver c) {
		// TODO
	}
}
