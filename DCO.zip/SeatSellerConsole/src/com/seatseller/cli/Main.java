package com.seatseller.cli;

public class Main {
	public static void main(String[] args) {
		new Startup();
	}
}
